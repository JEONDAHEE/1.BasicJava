package vo;

import java.util.Date;

public class PaymentVo {
	
	private int no;//������ȣ (pk)
	private int paymentNo;//������ȣ
	private Date data;//������
	private String id;//ȸ��Id
	private int milieage;//���ϸ���
	private int tableNo;//���̺� ��ȣ
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getPaymentNo() {
		return paymentNo;
	}
	public void setPaymentNo(int paymentNo) {
		this.paymentNo = paymentNo;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getMilieage() {
		return milieage;
	}
	public void setMilieage(int milieage) {
		this.milieage = milieage;
	}
	public int getTableNo() {
		return tableNo;
	}
	public void setTableNo(int tableNo) {
		this.tableNo = tableNo;
	}
	
	
	
	
}
