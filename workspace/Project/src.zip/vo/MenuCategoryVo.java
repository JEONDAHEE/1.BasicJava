package vo;

public class MenuCategoryVo {//pk�߰� ����
	
	private int no;//pk
	private String menu;//ī�װ��� �̸�

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}
}
