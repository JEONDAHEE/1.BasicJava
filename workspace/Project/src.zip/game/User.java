package game;

public class User {
	String user_ID;
	String user_PW;
	int milieage;
	}
