package service;

import java.util.Scanner;

import data.Database;

public class Notice {
	private static Notice instance;

	private Notice() {
	}

	public static Notice getInstance() {
		if (instance == null) {
			instance = new Notice();
		}
		return instance;
	}

	
	void NotiveView(){
		
		Database database = Database.getInstance();
		
		Scanner s = new Scanner(System.in);
		int select = s.nextInt();
		
		System.out.println("-----------------------------------------------");
		for(int i = 0; i < database.tb_notive.size(); i++){
			System.out.print(database.tb_notive.get(i).getNumber()+"\t");
			System.out.print(database.tb_notive.get(i).getSubject()+"\t");
			System.out.print(database.tb_notive.get(i).getId()+"\t");
			System.out.println(database.tb_notive.get(i).getContents());
			
		}
		

		
		
		
	}
void NoticeAdd(){
		
	}
}
