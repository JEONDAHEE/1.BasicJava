package service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

import vo.CartVo;
import vo.MenuCategoryVo;
import data.Database;

public class Menu {

	private static Menu instance;

	private Menu() {
	}

	public static Menu getInstance() {
		if (instance == null) {
			instance = new Menu();
		}
		return instance;
	}

	Scanner s = new Scanner(System.in);
	
	Database database = Database.getInstance();

	public void selectMenu() {

		Scanner s = new Scanner(System.in);
		String temp = "";
		boolean check = false;
		boolean null_check = true;

		 do {
			System.out
					.println("-----------------------------------------------");
			System.out.println(" �ֹ� �Ͻðڽ��ϱ� ??? "); // �ֹ�
			System.out.println(" ���Ͻô� �޴��� ������ ��ȣ�� �Է� �� �ּ���. ");
			for (int i = 0; i < database.tb_cartegory.size(); i++) {
				System.out.print(i + 1 + ". "
						+ database.tb_cartegory.get(i).getMenu() + "  ");
			}
			System.out.println("0. �׸� ���");
			System.out
					.println("-----------------------------------------------");

			check = true;
			temp = s.nextLine().trim();
			if(!temp.equals("")){
				for (int i = 0; i < temp.length(); i++) {
					if (temp.charAt(i) < '0' || temp.charAt(i) > '9') {
						check = false;
						break;
					}
				}
			
				if (check && 
						(Integer.parseInt(temp) - 1 > database.tb_cartegory.size() &&
								Integer.parseInt(temp) - 1 <= 0 )) {
					check = false;
				}
				if (!check) {
					System.out.println("�߸��� �Է��Դϴ�.");
				}
			}else{
				check = false;
			}
			
			
		} while (!check);
		 
		if(Integer.parseInt(temp) == 0){
			return;
		}
		
		int input = Integer.parseInt(temp) - 1;
		int menuCount = 0; 
		ArrayList<Integer> indexSpace = new ArrayList<>(); 
		
		do {
			
			for (int i = 0; i < database.tb_food.size(); i++) {
				if (database.tb_food.get(i).getCategory()
						.equals(database.tb_cartegory.get(input).getMenu())){
					indexSpace.add(i);
					null_check = false; 
				}
			}
			if(null_check){
				System.out.println("�ش� ī�װ��� �޴��� �����ϴ�.");
				System.out.println("�ڷ� ���ư��ϴ�.");
				return;
			}
			System.out
					.println("-----------------------------------------------");
			System.out.println(database.tb_cartegory.get(input).getMenu() + "�޴��Դϴ�.");
			System.out.println("���Ͻô� �޴��� ���� ���ּ���");
			for(int i = 0 ; i < indexSpace.size();i++){
				System.out.println(i+1+". "+database.tb_food.get(indexSpace.get(i)).getName());
			}
			
			System.out
					.println("-----------------------------------------------");

			check = true;
			temp = s.nextLine().trim();
			if(!temp.equals("")){
				for (int i = 0; i < temp.length(); i++) {
					if (temp.charAt(i) < '0' || temp.charAt(i) > '9') {
						check = false;
						break;
					}
				}
				if (check && 
						(Integer.parseInt(temp) - 1 > menuCount &&
								Integer.parseInt(temp) - 1 < 0 )) {
					check = false;
				}
				if (!check) {
					System.out.println("�߸��� �Է��Դϴ�.");
				}
			}else{
				check = false;
			}
			
		} while (!check);
		
		int input2 = indexSpace.get(Integer.parseInt(temp)-1);
	
				
		do {
			System.out.println(database.tb_food.get(input2).getName()
					+ "�� �����ϼ̽��ϴ�. � �ֹ� �Ͻðڽ��ϱ�?");
			temp = s.nextLine().trim();
			if(!temp.equals("")){
				check = true;
				for (int i = 0; i < temp.length(); i++) {
					if (temp.charAt(i) < '0' || temp.charAt(i) > '9') {
						check = false;
					}
				}
				if (!check) {
					System.out.println("�ٽ� �Է� �ϼ���.");
				}
			}else{
				check = false;
			}
			
		} while (!check);

		int count = Integer.parseInt(temp);

		
		boolean cartCheak = false;
		if (database.tb_cart.size() == 0) {
			
			CartVo cart = new CartVo();
			cart.setCount(count);
			cart.setName(database.tb_food.get(input2).getName());
			cart.setPrice(database.tb_food.get(input2).getPrice());
			database.tb_cart.add(cart);
		} else {
			for (int i = 0; i < database.tb_cart.size(); i++) {
				if (database.tb_cart.get(i).getName()
						.equals(database.tb_food.get(input2).getName())) {
					database.tb_cart.get(i).setCount(
							database.tb_cart.get(i).getCount() + count);
					cartCheak = true;
					break;
				}
			}
			if (!cartCheak) {
				CartVo cart = new CartVo();
				cart.setCount(count);
				cart.setName(database.tb_food.get(input2).getName());
				cart.setPrice(database.tb_food.get(input2).getPrice());
				database.tb_cart.add(cart);
			}
			
		}
		

	}

}
