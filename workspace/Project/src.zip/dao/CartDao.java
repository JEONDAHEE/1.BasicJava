package dao;

import java.util.ArrayList;

import vo.CartVo;
import vo.FoodVo;
import data.Database;

public class CartDao {
	private static CartDao instance;

	private CartDao() {
		
	}

	public static CartDao getInstance() {
		if (instance == null) {
			instance = new CartDao();
		}
		return instance;

	}

	Database database = Database.getInstance();


	public void insertCart(CartVo cart) {
		database.tb_cart.add(cart);
	}
	
	public void deleteCart(CartVo cart) {
		database.tb_cart.remove(cart);
	}
	
	public ArrayList<CartVo> selectCartList() {

		return database.tb_cart;
	}
	
	public void changeCartList(ArrayList<CartVo> tb_cart) {
		database.tb_cart=tb_cart;
	}
}
