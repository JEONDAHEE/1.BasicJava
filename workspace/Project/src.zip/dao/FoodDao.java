package dao;

import java.util.ArrayList;

import vo.FoodVo;
import data.Database;

public class FoodDao {
	private static FoodDao instance;

	private FoodDao() {
		
	}

	public static FoodDao getInstance() {
		if (instance == null) {
			instance = new FoodDao();
		}
		return instance;

	}

	Database database = Database.getInstance();


	public void insertFood(FoodVo food) {
		database.tb_food.add(food);
	}
	
	public void deleteFood(FoodVo food) {
		database.tb_food.remove(food);
	}
	
	public ArrayList<FoodVo> selectFoodList() {

		return database.tb_food;
	}
	

}

