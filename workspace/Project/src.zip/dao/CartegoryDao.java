package dao;

import java.util.ArrayList;

import vo.MenuCategoryVo;
import data.Database;

public class CartegoryDao {
	private static CartegoryDao instance;

	private CartegoryDao() {
		
	}

	public static CartegoryDao getInstance() {
		if (instance == null) {
			instance = new CartegoryDao();
		}
		return instance;

	}

	Database database = Database.getInstance();


	public void insertCategory(MenuCategoryVo category) {
		database.tb_cartegory.add(category);
	}

	public ArrayList<MenuCategoryVo> selectCategoryList() {

		return database.tb_cartegory;
	}
}
