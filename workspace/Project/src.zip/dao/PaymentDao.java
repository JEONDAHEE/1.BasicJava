package dao;

import java.util.ArrayList;

import vo.PaymentVo;
import data.Database;

public class PaymentDao {
	private static PaymentDao instance;

	private PaymentDao() {
		
	}

	public static PaymentDao getInstance() {
		if (instance == null) {
			instance = new PaymentDao();
		}
		return instance;

	}

	Database database = Database.getInstance();


	public void insertCart(PaymentVo payment) {
		database.tb_paymnet.add(payment);
	}
	
	public void deleteCart(PaymentVo payment) {
		database.tb_paymnet.remove(payment);
	}
	
	public ArrayList<PaymentVo> selectCartList() {

		return database.tb_paymnet;
	}
	
	public void changeCartList(ArrayList<PaymentVo> tb_paymnet) {
		database.tb_paymnet=tb_paymnet;
	}
}
